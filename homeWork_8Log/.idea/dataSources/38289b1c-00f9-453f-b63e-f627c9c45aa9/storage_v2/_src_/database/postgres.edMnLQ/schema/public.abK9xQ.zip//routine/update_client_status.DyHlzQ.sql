create function update_client_status() returns trigger
    language plpgsql
as
$$
DECLARE
    cut_id int;
	cut_status_id int;
BEGIN
    IF    TG_OP = 'INSERT' THEN
        cut_id = NEW.id;
		cut_status_id = (SELECT id FROM statuses  WHERE alias = 'STANDART');
        INSERT INTO client_status(client_id,status_id) VALUES (cut_id, cut_status_id);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        cut_id = OLD.id;
        DELETE FROM client_status WHERE client_id = cut_id;
        RETURN OLD;
    END IF;
END;
$$;

alter function update_client_status() owner to postgres;

