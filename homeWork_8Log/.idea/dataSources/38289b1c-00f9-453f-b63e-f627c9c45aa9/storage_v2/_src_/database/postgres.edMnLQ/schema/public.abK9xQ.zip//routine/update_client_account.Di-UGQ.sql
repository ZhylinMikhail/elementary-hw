create function update_client_account() returns trigger
    language plpgsql
as
$$
DECLARE
    cut_id int;
	cut_number bigint;
	cut_value double precision;
BEGIN
    IF    TG_OP = 'INSERT' THEN
        cut_id = NEW.id;
		cut_number =  CAST (floor(random()*(111111111111-999999999999)+1000000000000) AS varchar);
		cut_value = random()*(100-500)+500;
        INSERT INTO accounts(client_id,number,value) VALUES (cut_id,cut_number,cut_value);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        cut_id = OLD.id;
        DELETE FROM accounts WHERE client_id = cut_id;
        RETURN OLD;
    END IF;
END;
$$;

alter function update_client_account() owner to postgres;

